// Copyright Vince Bracken

#include "AbilitySystem/Abilities/AuraSummonFireMinions.h"
#include "AbilitySystem/Abilities/AuraSummonAbility.h"
#include "GameFramework/Character.h"
#include "Kismet/KismetSystemLibrary.h"
#include "TimerManager.h"
#include "AbilitySystemBlueprintLibrary.h"
#include "AbilitySystemComponent.h"
#include "AIController.h"
#include <AbilitySystem/AuraAbilitySystemLibrary.h>


TArray<FVector> UAuraSummonFireMinions::GetSpawnLocations()
{

	TArray<FVector> SpawnLocations = Super::GetSpawnLocations();
	return SpawnLocations;
}

void UAuraSummonFireMinions::OnMinionSpawned(AActor* Minion)
{
	if (!Minion) return;

	// Apply Fire Effect on Minion
	if (FireEffect)
	{
		UAbilitySystemComponent* ASC = UAbilitySystemBlueprintLibrary::GetAbilitySystemComponent(Minion);
		if (ASC)
		{
			FGameplayEffectContextHandle EffectContext = ASC->MakeEffectContext();
			ASC->ApplyGameplayEffectToSelf(FireEffect->GetDefaultObject<UGameplayEffect>(), 1.0f, EffectContext);
		}
	}

	// Assign AI to chase the nearest enemy
	AAIController* AIController = GetWorld()->SpawnActor<AAIController>(AAIController::StaticClass());
	if (AIController)
	{
		AIController->Possess(Cast<APawn>(Minion));
		TArray<AActor*> PotentialTargets;
		TArray<AActor*> ActorsToIgnore;
		ActorsToIgnore.Add(Minion); // Avoid targeting itself

		UAuraAbilitySystemLibrary::GetLivePlayersWithinRadius(
			this,                // Context
			PotentialTargets,    // Out array of found actors
			ActorsToIgnore,      // Ignore self
			1000.f,              // Adjust radius as needed
			Minion->GetActorLocation() // Sphere origin
		);

		// Select a random or first target
		AActor* Target = PotentialTargets.Num() > 0 ? PotentialTargets[0] : nullptr;
		if (AIController && Target)
		{
			AIController->MoveToActor(Target);
		}
	}

	// Set Explosion Timer
	FTimerHandle ExplosionTimer;
	FTimerDelegate TimerDelegate;
	TimerDelegate.BindUObject(this, &UAuraSummonFireMinions::ExplodeMinion, Minion);
	GetWorld()->GetTimerManager().SetTimer(ExplosionTimer, TimerDelegate, ExplosionDelay, false);
}

void UAuraSummonFireMinions::ExplodeMinion(AActor* Minion)
{
	if (!Minion) return;

	// Apply explosion damage
	if (ExplosionDamageEffect)
	{
		TArray<AActor*> AffectedActors;
		UKismetSystemLibrary::SphereOverlapActors(
			GetWorld(),
			Minion->GetActorLocation(),
			ExplosionRadius,
			TArray<TEnumAsByte<EObjectTypeQuery>>(),
			ACharacter::StaticClass(),
			TArray<AActor*>(),
			AffectedActors);

		for (AActor* Target : AffectedActors)
		{
			UAbilitySystemComponent* TargetASC = UAbilitySystemBlueprintLibrary::GetAbilitySystemComponent(Target);
			if (TargetASC)
			{
				FGameplayEffectSpecHandle EffectSpec = TargetASC->MakeOutgoingSpec(ExplosionDamageEffect, 1.0f, TargetASC->MakeEffectContext());
				TargetASC->ApplyGameplayEffectSpecToSelf(*EffectSpec.Data.Get());
			}
		}
	}

	// Destroy Minion
	Minion->Destroy();
}

