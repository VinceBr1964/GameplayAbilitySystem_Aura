// Copyright Vince Bracken


#include "Interaction/HighlightInterface.h"

// Add default functionality here for any IHighlightInterface functions that are not pure virtual.
